﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.ServiceModel;
using ConsoleApplication.Models;
using ConsoleApplication.PriceChangeContracts;
using TableDependency.SqlClient;
using TableDependency.SqlClient.Base.EventArgs;

namespace ConsoleApplication.PriceChangeService
{
    [ServiceBehavior(InstanceContextMode =InstanceContextMode.Single, ConcurrencyMode =ConcurrencyMode.Single)]
    class PriceTicker
    {
        private readonly List<IPriceChangeCallBak> _callbackList = new List<IPriceChangeCallBak>();
        private readonly string _connectionString;
        private readonly SqlTableDependency<Stock> _sqlTableDependency;

        public PriceTicker()
        {
            _connectionString = ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString;
            _sqlTableDependency = new SqlTableDependency<Stock>(_connectionString, "Stocks");

            _sqlTableDependency.OnChanged += TableDependency_Changed;
            _sqlTableDependency.OnError += (sender, args) => Console.WriteLine($"Error:{args.Message}");
            _sqlTableDependency.Start();

            Console.WriteLine(@"Waiting for receiving notifications ...");

        }

        private void TableDependency_Changed(object sender, RecordChangedEventArgs<Stock> e)
        {
            Console.WriteLine(Environment.NewLine);
            Console.WriteLine($"DML:{e.ChangeType}");
            Console.WriteLine($"Code:{e.Entity.Code}");
            Console.WriteLine($"Name:{e.Entity.Name}");
            Console.WriteLine($"Price:{e.Entity.Price}");

            this.PublishPriceChange(e.Entity.Code, e.Entity.Name, e.Entity.Price);


        }

        public IList<Stock> GetAllStocks()
        {
            var stocks = new List<Stock>();
            using (var sqlConnection=new SqlConnection(_connectionString))
            {
                sqlConnection.Open();
                using(var sqlCommand = sqlConnection.CreateCommand())
                {
                    sqlCommand.CommandText = "select * from [Stocks]";

                    using (var sqlDataReader = sqlCommand.ExecuteReader())
                    {
                        while(sqlDataReader.Read())
                        {
                            var code = sqlDataReader.GetString(sqlDataReader.GetOrdinal("Code"));
                            var name = sqlDataReader.GetString(sqlDataReader.GetOrdinal("Name"));
                            var price = sqlDataReader.GetDecimal(sqlDataReader.GetOrdinal("Price"));

                            stocks.Add(new Stock { Code = code, Name = name, Price = price });

                        }

                    }

                }
            }
            return stocks;

        }

        public void Subscribe()
        {
            var registeredUser = OperationContext.Current.GetCallbackChannel<IPriceChangeCallBak>();
            if(!_callbackList.Contains(registeredUser))
            {
                _callbackList.Add(registeredUser);
            }
        }

        public void Unsubscribe()
        {
            var registeredUser = OperationContext.Current.GetCallbackChannel<IPriceChangeCallBak>();
            if(_callbackList.Contains(registeredUser))
            {

                _callbackList.Remove(registeredUser);
            }

        }

        public void PublishPriceChange(string code, string name , decimal price)
        {
            _callbackList.ForEach(delegate (IPriceChangeCallBak callback) { callback.PriceChange(code, name, price); });
        }

        public void Dispose()
        {
            _sqlTableDependency.Stop();
        }

    }
}

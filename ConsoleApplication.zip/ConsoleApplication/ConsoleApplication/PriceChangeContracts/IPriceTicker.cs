﻿using ConsoleApplication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication.PriceChangeContracts
{
    [ServiceContract(CallbackContract=typeof(IPriceChangeCallBak))]
    interface IPriceTicker
    {
        [OperationContract]
        void Suscribe();

        [OperationContract]
        void Unscribe();

        [OperationContract]
        IList<Stock> GetAllStocks();

        [OperationContract]
        void PublishPriceChange(string item, string name, decimal price);

    }
}
